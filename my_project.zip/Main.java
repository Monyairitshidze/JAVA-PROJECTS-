
// Online IDE - Code Editor, Compiler, Interpreter

public class Main
{
    public static void main(String[] args) {
      
       for(int i =1; i<8 ; i++){
           
          
           
           if (i==3){
               continue;
           }
           
            System.out.println(i);
       }
    }
}
